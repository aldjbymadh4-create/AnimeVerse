const pages=[...document.querySelectorAll(".page")];
function go(page){
  pages.forEach(p=>p.classList.toggle("hidden",p.id!==page));
  document.querySelectorAll("[data-page]").forEach(b=>b.classList.toggle("active",b.dataset.page===page));
  window.scrollTo({top:0,behavior:"smooth"});
}
document.addEventListener("click",e=>{
  const el=e.target.closest("[data-page]");
  if(el) go(el.dataset.page);
});
const animeNames=["One Piece","Naruto","Demon Slayer","Jujutsu Kaisen","Attack on Titan","Solo Leveling","Bleach","My Hero Academia"];
const large=document.querySelector("#anime .anime-grid");
large.innerHTML=animeNames.map((n,i)=>`<article class="anime-card"><div class="poster p${i%4+1}">${n.replace(" ","<br>")}</div><b>${n}</b><small>متاح للمشاهدة • ⭐ ${(9.0+i%9/10).toFixed(1)}</small></article>`).join("");

let deferredPrompt;
const installBar=document.getElementById("installBar");
window.addEventListener("beforeinstallprompt",e=>{
  e.preventDefault(); deferredPrompt=e; installBar.classList.remove("hidden");
});
document.getElementById("installBtn").onclick=async()=>{
  if(!deferredPrompt)return;
  deferredPrompt.prompt(); await deferredPrompt.userChoice; deferredPrompt=null; installBar.classList.add("hidden");
};
document.getElementById("closeInstall").onclick=()=>installBar.classList.add("hidden");

if("serviceWorker" in navigator) navigator.serviceWorker.register("sw.js").catch(()=>{});
document.getElementById("searchInput").addEventListener("keydown",e=>{
  if(e.key==="Enter"){
    go("anime");
    const q=e.target.value.trim().toLowerCase();
    if(q) document.querySelectorAll(".anime-card").forEach(c=>c.style.display=c.innerText.toLowerCase().includes(q)?"":"none");
  }
});
